// using tripsEndpoint in api/trips
const tripsEndpoint = "http://localhost:3000/api/trips";
const options = {
  method: "GET",
  headers: {
    Accept: "application/json",
  },
};
// Read trips.json file
//const fs = require('fs');
//const trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf-8'));

/* GET Travel View */
const travel = async function (req, res, next) {
  //console.log("TRAVEL CONTROLLER BEGIN");
  await fetch(tripsEndpoint, options)
    .then((res) => res.json())
    .then((json) => {
      //console.log(json);
      let message = null;
      if (!(json instanceof Array)) {
        message = "API lookup Error";
        json = [];
      } else {
        if (!json.length) {
          message = "No trips exist in our database";
        }
      }
      res.render("travel", {
        title: "Travlr Getaways",
        trips: json,
        message,
      });
    })
    .catch((err) => res.status(500).send(err.message));
};

module.exports = {
  travel,
};

// updated to be inline with modern javascript, var is depreciated 
const express = require("express");
const router = express.Router();
// added ctrlMain to get main from ../controllers
const ctrlMain = require("../controllers/main");

/* GET home page. */
router.get("/", ctrlMain.index); // updated to pull index from ctrlMain => ../controllers/main.js
module.exports = router;

import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { trips } from '../data/trips';
import { TripCard } from '../trip-card/trip-card';

import { Authentication } from '../services/authentication';
import { Trip } from '../models/trips';
import { TripData } from '../services/trip-data';

import { Router } from '@angular/router';
@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCard],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css',
  providers: [TripData],
})
export class TripListing implements OnInit {
  trips = signal<Array<any>>(trips);
  message: string = '';

  constructor(
    private tripDataService: TripData,
    private router: Router,
    private authentication: Authentication,
  ) {
    console.log('trip-listing constructor');
  }

  ngOnInit(): void {
    console.log('ngOnInit');
    this.getTrips();
  }

  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  getTrips(): void {
    this.tripDataService.getTrips().subscribe({
      next: (value: any) => {
        this.trips.set(value);
        if (value.length > 0) {
          this.message = 'There are ' + value.length + ' trips available';
        } else {
          this.message = 'There are no trips retrieved from the database';
        }

        console.log(this.message);
      },
      error: (error: any) => {
        console.log('Error: ' + error);
      },
    });
  }

  public onDeleteTrip(trip: Trip): void {
    this.tripDataService.deleteTrip(trip.code).subscribe({
      next: () => this.getTrips(),
      error: (error: any) => console.log('Error: ' + error),
    });
  }

  public isLoggedIn() {
    return this.authentication.isLoggedIn();
  }
}

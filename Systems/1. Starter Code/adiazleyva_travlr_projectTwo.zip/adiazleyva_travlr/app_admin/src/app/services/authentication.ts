import { Inject, Injectable } from '@angular/core';
import { BROWSER_STORAGE } from '../storage';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { TripData } from './trip-data';

@Injectable({
  providedIn: 'root',
})
export class Authentication {
  // Setup storage and service aces
  constructor(
    @Inject(BROWSER_STORAGE) private storage: Storage,
    private tripData: TripData,
  ) {}

  // Handles auth response
  authResp: AuthResponse = new AuthResponse();

  // Get token from Stroage, token named travlr-token
  public getToken(): string {
    let out: any;
    out = this.storage.getItem('travlr-token');

    if (!out) {
      return '';
    } else {
      return out;
    }
  }

  // Save token to storage
  public saveToken(token: string): void {
    this.storage.setItem('travlr-token', token);
  }

  // Logout of Application
  public logout(): void {
    this.storage.removeItem('travlr-token');
  }

  // Determine if we are logged in and token is valid
  public isLoggedIn(): boolean {
    const token: string = this.getToken();
    if (token) {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > Date.now() / 1000;
    } else {
      return false;
    }
  }

  // Get current user
  public getCurrentUser(): User {
    const token: string = this.getToken();
    const { email, name } = JSON.parse(atob(token.split('.')[1]));
    return { email, name } as User;
  }

  // Login, using TripData login method
  public login(user: User, password: string): void {
    this.tripData.login(user, password).subscribe({
      next: (value: any) => {
        if (value) {
          this.authResp = value;
          this.saveToken(this.authResp.token);
        }
      },
      error: (error: any) => {
        console.log('Error: ' + error);

      }
    })
  }

  // Register using TripDate register method
  public register(user: User, password: string) : void{
    this.tripData.register(user, password). subscribe({
      next: (value: any) => {
        if (value) {
          this.authResp = value;
          this.saveToken(this.authResp.token);
        }
      },
      error: (error: any) => {
        console.log('Error: ' + error);
      }
    })
  }
}

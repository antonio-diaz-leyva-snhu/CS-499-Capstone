import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BROWSER_STORAGE } from '../storage';

import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { Trip } from '../models/trips';

@Injectable({
  providedIn: 'root',
})
export class TripData {
  baseurl = 'http://localhost:3000/api';
  url = 'http://localhost:3000/api/trips';

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage,
  ) {}

  getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.url);
  }

  addTrip(formData: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.url, formData);
  }

  getTrip(tripCode: string): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.url + '/' + tripCode);
  }

  updateTrip(formData: Trip): Observable<Trip> {
    return this.http.put<Trip>(this.url + '/' + formData.code, formData);
  }

  deleteTrip(tripCode: string): Observable<any> {
    return this.http.delete(this.url + '/' + tripCode);
  }

  // login and register endpoints for authentication service
  login(user: User, password: string): Observable<AuthResponse> {
    return this.handleAuthAPICall('login', user, password);
  }

  register(user: User, password: string): Observable<AuthResponse> {
    return this.handleAuthAPICall('register', user, password);
  }

  // helper to process both loging and register
  handleAuthAPICall(endpoint: string, user: User, password: string): Observable<AuthResponse> {
    let formData = {
      name: user.name,
      email: user.email,
      password: password,
    };

    return this.http.post<AuthResponse>(this.baseurl + '/' + endpoint, formData);
  }
}

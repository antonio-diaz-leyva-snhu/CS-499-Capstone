const mongoose = require("mongoose");
const passport = require("passport");
const User = require("../models/users");

const register = async (req, res) => {
  // validate message to insure all parameters present
  if (!req.body.name || !req.body.email || !req.body.password) {
    return res.status(400).json({ message: "All fields required" });
  }

  const user = new User({
    name: req.body.name,
    email: req.body.email,
    password: "",
  });
  user.setPassword(req.body.password);
  const q = await user.save();

  if (!q) {
    return res.status(400).json(err);
  } else {
    const token = user.generateJWT();
    return res.status(200).json(token);
  }
};

const login = (req, res) => {
  // verify fields set
  if (!req.body.email || !req.body.password) {
    return res.status(400).json({ message: "All fields required" });
  }

  // delegate auth to passport module
  passport.authenticate("local", (err, user, info) => {
    if (err) {
      // error in auth
      return res.status(404).json(err);
    }

    if (user) {
      const token = user.generateJWT();
      res.status(200).json({ token });
    } else {
      // auth failed return rerror
      res.status(401).json(info);
    }
  })(req, res);
};

module.exports = {
  register,
  login,
};

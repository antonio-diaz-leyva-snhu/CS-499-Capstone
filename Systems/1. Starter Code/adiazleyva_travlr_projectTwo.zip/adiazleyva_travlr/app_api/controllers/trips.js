const mongoose = require("mongoose");
const Trip = require("../models/travlr"); // register model
const Model = mongoose.model("trips");

//Get /trips - list all trips
// regardless of outcome response must include HTML status code
// and JSON messge to the request client
const tripsList = async (req, res) => {
  const q = await Model.find({}).exec();

  // Console debugging
  //console.log(q);

  if (!q) {
    return res.status(404).json(err);
  } else {
    return res.status(200).json(q);
  }
};

// GET /trips/:tripCode
const tripsFindByCode = async (req, res) => {
  const q = await Model.find({ code: req.params.tripCode }) // return single record
    .exec();

  //console logging
  //console.log(q);

  if (!q) {
    // no data returned
    return res
      .status(404) // status code
      .json(err); // json message
  } else {
    return res
      .status(200) // status code
      .json(q); // json message
  }
};

//Post: /trips add new trip
const tripsAddTrip = async (req, res) => {
  const newTrip = new Trip({
    code: req.body.code,
    name: req.body.name,
    length: req.body.length,
    start: req.body.start,
    resort: req.body.resort,
    perPerson: req.body.perPerson,
    image: req.body.image,
    description: req.body.description,
  });

  const q = await newTrip.save();

  if (!q) {
    return res.status(400).json(err);
  } else {
    return res.status(201).json(q);
  }
};

// PUT: /trips/:tripCode - Adds a new Trip
const tripsUpdateTrip = async (req, res) => {
  // Uncomment for debugging
  console.log(req.params);
  console.log(req.body);

  const q = await Model.findOneAndUpdate(
    { code: req.params.tripCode },
    {
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description,
    },
  ).exec();

  if (!q) {
    // Database returned no data
    return res.status(400).json(err);
  } else {
    // Return resulting updated trip
    return res.status(201).json(q);
  }

  // console.log(q);
};

const tripsDeleteTrip = async (req, res) => {
  const q = await Model.findOneAndDelete({ code: req.params.tripCode }).exec();

  if (!q) {
    return res.status(404).json(err);
  } else {
    return res.status(200).json(q);
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip,
};

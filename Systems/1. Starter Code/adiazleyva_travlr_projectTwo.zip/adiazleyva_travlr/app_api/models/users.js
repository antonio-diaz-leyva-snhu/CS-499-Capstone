const mongoose = require("mongoose");
const crypto = require("crypto");
const jwt = require("jsonwebtoken");

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    unique: true,
    requried: true,
  },
  name: {
    type: String,
    requried: true,
  },
  hash: String,
  salt: String,
});

// Set password on record
userSchema.methods.setPassword = function (password) {
  this.salt = crypto.randomBytes(16).toString("hex");
  this.hash = crypto
    .pbkdf2Sync(password, this.salt, 1000, 64, "sha512")
    .toString("hex");
};

userSchema.methods.validPassword = function (password) {
  const hash = crypto
    .pbkdf2Sync(password, this.salt, 1000, 64, "sha512")
    .toString("hex");
  return this.hash === hash;
};

userSchema.methods.generateJWT = function () {
  return jwt.sign(
    // payload
    {
      _id: this.id,
      email: this.email,
      name: this.name,
    },
    process.env.JWT_SECRET, // secret stored in env file
    { expiresIn: "1h" },
  );
};

const User = mongoose.model("users", userSchema);
module.exports = User;

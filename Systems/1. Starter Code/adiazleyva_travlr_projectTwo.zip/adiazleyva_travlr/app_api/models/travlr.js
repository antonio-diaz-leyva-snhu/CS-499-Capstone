// imports/requires
const mongoose = require('mongoose');

// Trip schema
const tripSchema = new mongoose.Schema({
  code: { type: String, required: true, index: true },
  name: { type: String, required: true, index: true },
  length: { type: String, required: true },
  start: { type: Date, requried: true },
  resort: { type: String, requried: true },
  perPerson: { type: String, required: true },
  image: { type: String, required: true },
  description: { type: String, required: true },
});

const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;

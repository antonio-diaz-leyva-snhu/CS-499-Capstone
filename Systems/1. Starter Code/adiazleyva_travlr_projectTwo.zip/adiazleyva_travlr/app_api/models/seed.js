// DB connection and trip schema
const Mongoose = require('./db');
const Trip = require('./travlr');

// Read seed data from json
const fs = require('fs');
const trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf8'));

// delete existin records, then insert seed data
const seedDB = async () => {
    await Trip.deleteMany({});
    await Trip.insertMany(trips);
};

// Close connection and exit
seedDB().then(async () => {
    await Mongoose.connection.close();
    process.exit(0);
});
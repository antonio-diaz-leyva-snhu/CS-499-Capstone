// imports/requires
const mongoose = require('mongoose');
const readLine = require('readline');


// connection setup
const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = `mongodb://${host}/travlr`;

// Build Connection
// Timeout in milliseconds
const connect = () => {
    setTimeout(() => mongoose.connect(dbURI, {}), 1000);
}

// Monitor Connection events
mongoose.connection.on('connected', () => {
    console.log(`Mongoose is connected to ${dbURI}`);
});

mongoose.connection.on('error', err => {
    console.log('Mongoose connection error: ', err);
});

mongoose.connection.on('disconected', () => {
    console.log('Mongoose disconnected');    
});

if(process.platform === 'win32'){
    const r1 = readLine.createInterface({
        input: process.stdin,
        ouptut: process.stdout
    });
    r1.on('SIGINT', () => {
        process.emit('SIGINT');
    });
}

// Configure for Graceful Shutdown
const gracefulShutdown = (msg) => {
    mongoose.connection.close(() => {
        console.log(`Mongoose is disconnected through ${msg}`);
    });
};

// Event listeners to process graceful shutdowns

// Shutdown by nodemon signal
process.prependOnceListener('SIGUSR2', () => {
    gracefulShutdown.apply('nodemon restart');
    process.kill(process.pid, 'SIGUSR2');
});

// Shutdown by app termination
process.on('SIGINT', () => {
    gracefulShutdown('app termination');
    process.exit(0);
})

// Shutdown by container termination
process.on('SIGTERM', () => {
    gracefulShutdown('app shutdown');
    process.exit(0);
});

// Make inital conection to DB
connect();

// Import Mongoose Schema (Trip)
require("./travlr");
module.exports = mongoose;